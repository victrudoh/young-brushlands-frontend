import styled from 'styled-components'

export const Dashboard = styled.div`

`;