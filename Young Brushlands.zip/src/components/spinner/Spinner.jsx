import React from 'react'

import { Spinner } from './Spinner.Styles'


export default Spinner;