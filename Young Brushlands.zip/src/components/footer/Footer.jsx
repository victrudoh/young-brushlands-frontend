import React from 'react'

// styles
import { Wrapper } from './Footer.Styles'

const Footer = () => {
  return (
    <>
      <Wrapper>&copy; Young Brushlands 2022</Wrapper>
    </>
  );
}

export default Footer